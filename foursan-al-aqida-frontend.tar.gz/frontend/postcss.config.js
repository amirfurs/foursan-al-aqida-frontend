/**
 * إعداد PostCSS لتشغيل Tailwind CSS و Autoprefixer.
 */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};