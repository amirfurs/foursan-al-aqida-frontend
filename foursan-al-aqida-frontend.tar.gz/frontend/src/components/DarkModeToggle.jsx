import React from 'react';

/**
 * زر بسيط لتبديل الوضع الليلي/النهاري.
 * يستقبل حالة الوضع الليلي ودالة لتغييرها.
 */
export default function DarkModeToggle({ dark, setDark }) {
  return (
    <button
      className="ml-2 text-accent focus:outline-none"
      onClick={() => setDark(!dark)}
      aria-label={dark ? 'تفعيل الوضع النهاري' : 'تفعيل الوضع الليلي'}
    >
      {dark ? '☀️' : '🌙'}
    </button>
  );
}