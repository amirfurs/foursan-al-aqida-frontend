import React from 'react';
import { Link } from 'react-router-dom';

/**
 * سحابة الوسوم التفاعلية. حجم كل وسم يتناسب مع عدد المقالات المرتبطة به.
 */
export default function TagCloud({ tags }) {
  if (!tags || tags.length === 0) return null;
  const maxCount = Math.max(...tags.map((t) => t.count));
  return (
    <section className="py-12 bg-primary dark:bg-primary border-t border-secondary/40">
      <div className="container mx-auto px-4">
          <h2 className="text-2xl font-amiri mb-6 text-accent">سحابة الوسوم</h2>
          <div className="flex flex-wrap gap-4">
            {tags.map((tag) => {
              const size = 1 + tag.count / maxCount; // حجم نسبي بين 1 و2
              return (
                <Link
                  key={tag.id}
                  to={`/tags/${tag.id}`}
                  title={`${tag.count} مقالات`}
                  className="text-lightText hover:text-accent transition-transform transform hover:scale-110"
                  style={{ fontSize: `${size}rem` }}
                >
                  {tag.name}
                </Link>
              );
            })}
          </div>
      </div>
    </section>
  );
}