import React from 'react';
import CategoryCard from './CategoryCard.jsx';

/**
 * قسم لعرض الأقسام الرئيسية للموقع. يتضمن شبكة من البطاقات.
 */
export default function CategoriesSection({ categories }) {
  return (
    <section className="py-12 bg-primary dark:bg-primary border-t border-secondary/40">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-amiri mb-6 text-accent">تصفّح حسب الأقسام</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {categories.map((cat) => (
            <CategoryCard key={cat.id} category={cat} />
          ))}
        </div>
      </div>
    </section>
  );
}