import React from 'react';
import { Link } from 'react-router-dom';

/**
 * بطاقة سلسلة علمية تُعرض في الكاروسيل.
 */
export default function SeriesCard({ series }) {
  return (
    <Link
      to={`/series/${series.id}`}
      className="block bg-secondary/20 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
    >
      <div className="relative">
        <img
          src={series.cover || '/images/series-placeholder.jpg'}
          alt={series.name}
          className="w-full h-40 object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lightText mb-1">{series.name}</h3>
        <p className="text-sm text-lightText/80 line-clamp-2">{series.description}</p>
      </div>
    </Link>
  );
}