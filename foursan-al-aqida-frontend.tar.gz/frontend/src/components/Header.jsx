import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import DarkModeToggle from './DarkModeToggle';

/**
 * مكون الترويسة (البار العلوي) للموقع. يحتوي على شعار الموقع، قائمة تنقل،
 * حقل البحث، زر الحساب، وزر تبديل الوضع الليلي.
 * التصميم متجاوب؛ حيث يتم إظهار قائمة جانبية على الشاشات الصغيرة.
 */
function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [sectionsOpen, setSectionsOpen] = useState(false);
  const navigate = useNavigate();

  const handleNavigation = (path) => {
    setMenuOpen(false);
    setSectionsOpen(false);
    navigate(path);
  };

  return (
    <header className="bg-primary text-light fixed top-0 inset-x-0 z-50 border-b border-secondary shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* شعار الموقع */}
          <Link to="/" className="text-2xl md:text-3xl font-serif font-extrabold text-accent">
            فرسان العقيدة
          </Link>
          {/* عناصر التحكم اليمنى */}
          <div className="flex items-center space-x-4 rtl:space-x-reverse">
            {/* قائمة التنقل في الوضع المكتبي */}
            <nav className="hidden md:flex items-center space-x-6 rtl:space-x-reverse text-base">
              <Link to="/" className="hover:text-accent transition-colors">الرئيسية</Link>
              {/* قائمة الأقسام */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setSectionsOpen(!sectionsOpen)}
                  className="flex items-center hover:text-accent focus:outline-none"
                  aria-haspopup="true"
                  aria-expanded={sectionsOpen}
                >
                  الأقسام
                  <span className="ml-1 rtl:mr-1">▾</span>
                </button>
                {sectionsOpen && (
                  <div className="absolute mt-2 right-0 bg-primary border border-secondary rounded-md shadow-lg w-48 py-2 z-50">
                    <button
                      onClick={() => handleNavigation('/section/aqeeda')}
                      className="block w-full text-right px-4 py-2 hover:bg-secondary/30 text-light"
                    >
                      العقيدة
                    </button>
                    <button
                      onClick={() => handleNavigation('/section/fiqh')}
                      className="block w-full text-right px-4 py-2 hover:bg-secondary/30 text-light"
                    >
                      الفقه
                    </button>
                    <button
                      onClick={() => handleNavigation('/section/seerah')}
                      className="block w-full text-right px-4 py-2 hover:bg-secondary/30 text-light"
                    >
                      السيرة
                    </button>
                  </div>
                )}
              </div>
              <Link to="/tags" className="hover:text-accent transition-colors">الوسوم</Link>
              <Link to="/series" className="hover:text-accent transition-colors">السلاسل</Link>
              <Link to="/about" className="hover:text-accent transition-colors">حول الموقع</Link>
            </nav>
            {/* حقل البحث - مخفي في الوضع الصغير */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const q = e.target.elements.q.value;
                if (q && q.trim()) navigate(`/search?q=${encodeURIComponent(q.trim())}`);
              }}
              className="hidden md:flex items-center"
            >
              <input
                type="search"
                name="q"
                placeholder="ابحث..."
                className="px-2 py-1 rounded-l-md bg-secondary text-light placeholder:opacity-75 focus:outline-none focus:ring-1 focus:ring-accent"
                autoComplete="off"
              />
              <button
                type="submit"
                className="px-3 py-1 bg-accent text-white rounded-r-md hover:bg-accent/80"
              >
                بحث
              </button>
            </form>
            {/* زر الحساب */}
            <button
              onClick={() => handleNavigation('/login')}
              className="hidden md:inline-flex items-center px-3 py-1 bg-accent text-white rounded-md hover:bg-accent/80 transition-colors"
            >
              حسابي
            </button>
            {/* زر تبديل الوضع الليلي */}
            <DarkModeToggle />
            {/* زر القائمة للهواتف */}
            <button
              className="md:hidden text-xl focus:outline-none"
              onClick={() => setMenuOpen(!menuOpen)}
              aria-label="قائمة"
            >
              ☰
            </button>
          </div>
        </div>
      </div>
      {/* القائمة الجانبية في الهاتف */}
      {menuOpen && (
        <div className="md:hidden bg-primary border-t border-secondary pt-4 pb-6 px-4 space-y-2">
          <button
            onClick={() => handleNavigation('/')}
            className="block w-full text-right px-2 py-2 hover:bg-secondary/30 rounded-md"
          >
            الرئيسية
          </button>
          <button
            onClick={() => setSectionsOpen(!sectionsOpen)}
            className="block w-full text-right px-2 py-2 hover:bg-secondary/30 rounded-md"
            aria-expanded={sectionsOpen}
          >
            الأقسام
          </button>
          {sectionsOpen && (
            <div className="ml-4 space-y-1">
              <button
                onClick={() => handleNavigation('/section/aqeeda')}
                className="block w-full text-right px-2 py-1 hover:bg-secondary/30 rounded-md"
              >
                العقيدة
              </button>
              <button
                onClick={() => handleNavigation('/section/fiqh')}
                className="block w-full text-right px-2 py-1 hover:bg-secondary/30 rounded-md"
              >
                الفقه
              </button>
              <button
                onClick={() => handleNavigation('/section/seerah')}
                className="block w-full text-right px-2 py-1 hover:bg-secondary/30 rounded-md"
              >
                السيرة
              </button>
            </div>
          )}
          <button
            onClick={() => handleNavigation('/tags')}
            className="block w-full text-right px-2 py-2 hover:bg-secondary/30 rounded-md"
          >
            الوسوم
          </button>
          <button
            onClick={() => handleNavigation('/series')}
            className="block w-full text-right px-2 py-2 hover:bg-secondary/30 rounded-md"
          >
            السلاسل
          </button>
          <button
            onClick={() => handleNavigation('/about')}
            className="block w-full text-right px-2 py-2 hover:bg-secondary/30 rounded-md"
          >
            حول الموقع
          </button>
          {/* حقل البحث في الهاتف */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const q = e.target.elements.q.value;
              if (q && q.trim()) {
                handleNavigation(`/search?q=${encodeURIComponent(q.trim())}`);
              }
            }}
            className="flex items-center mt-2"
          >
            <input
              type="search"
              name="q"
              placeholder="ابحث..."
              className="flex-1 px-2 py-1 bg-secondary text-light placeholder:opacity-75 focus:outline-none focus:ring-1 focus:ring-accent rounded-l-md"
            />
            <button
              type="submit"
              className="px-3 py-1 bg-accent text-white rounded-r-md hover:bg-accent/80"
            >
              بحث
            </button>
          </form>
          <button
            onClick={() => handleNavigation('/login')}
            className="block w-full text-right px-2 py-2 mt-2 bg-accent text-white rounded-md hover:bg-accent/80"
          >
            حسابي
          </button>
        </div>
      )}
    </header>
  );
}

export default Header;