import React from 'react';
import { Link } from 'react-router-dom';

/**
 * بطاقة عرض مقال مختصر. تظهر الصورة والوسم والعنوان والملخص وعدد الإعجابات والتعليقات.
 */
export default function ArticleCard({ article }) {
  return (
    <Link
      to={`/article/${article.id}`}
      className="block rounded-lg overflow-hidden bg-secondary/20 hover:shadow-lg transition-shadow w-full"
    >
      <div className="relative">
        <img
          src={article.cover || '/images/cover-placeholder.jpg'}
          alt={article.title}
          className="w-full h-40 object-cover"
        />
        {/* الوسم */}
        {article.tag && (
          <span className="absolute top-2 left-2 bg-accent text-white text-xs px-2 py-1 rounded">
            {article.tag}
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="font-bold mb-2 text-lightText">{article.title}</h3>
        <p className="text-sm text-lightText/80 mb-3 line-clamp-2">
          {article.summary}
        </p>
        <div className="flex justify-between text-xs text-lightText/60">
          <span>
            <i className="fas fa-heart ml-1"></i>
            {article.likes}
          </span>
          <span>
            <i className="fas fa-comment ml-1"></i>
            {article.comments}
          </span>
        </div>
      </div>
    </Link>
  );
}