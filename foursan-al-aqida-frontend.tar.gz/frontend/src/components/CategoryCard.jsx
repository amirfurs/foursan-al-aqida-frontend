import React from 'react';
import { Link } from 'react-router-dom';

/**
 * بطاقة قسم تعرض اسم القسم وعدد المقالات. يمكن إضافة أيقونة مخصّصة مستقبلاً.
 */
export default function CategoryCard({ category }) {
  return (
    <Link
      to={`/section/${category.id}`}
      className="flex flex-col items-center justify-center bg-secondary/20 text-lightText p-6 rounded-lg hover:shadow-md transition-shadow"
    >
      {/* أيقونة بديلة بسيطة */}
      <div className="text-accent text-4xl mb-2">
        <i className="fas fa-book-open"></i>
      </div>
      <h3 className="font-semibold mb-1">{category.name}</h3>
      <span className="text-sm text-lightText/60">{category.count} مقالات</span>
    </Link>
  );
}