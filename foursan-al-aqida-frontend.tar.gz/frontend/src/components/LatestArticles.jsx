import React from 'react';
import ArticleCard from './ArticleCard.jsx';

/**
 * قسم عرض أحدث المقالات. يستخدم شبكة على الشاشات الكبيرة وسلايدر أفقي على الشاشات الصغيرة.
 */
export default function LatestArticles({ articles }) {
  return (
    <section className="py-12 bg-primary dark:bg-primary">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-amiri mb-6 text-accent">أحدث المقالات</h2>
        {/* شبكة للسطح المكتب */}
        <div className="hidden md:grid grid-cols-3 gap-6">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
        {/* سلايدر بسيط للجوال */}
        <div className="flex md:hidden space-x-4 rtl:space-x-reverse overflow-x-auto hide-scrollbar">
          {articles.map((article) => (
            <div key={article.id} className="min-w-[80%] flex-shrink-0">
              <ArticleCard article={article} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}