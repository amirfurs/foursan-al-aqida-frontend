import React from 'react';
import { Link } from 'react-router-dom';

/**
 * مكون لعرض الأقسام الرئيسية للموقع. يأخذ مصفوفة من الكائنات تحتوي على
 * معرف القسم، الاسم، عدد المقالات، ورمز/أيقونة. عند الضغط على أي بطاقة
 * ينتقل المستخدم لصفحة القسم المعنية.
 */
function Categories({ categories = [] }) {
  return (
    <section className="my-12">
      <h2 className="text-2xl md:text-3xl font-serif mb-4 text-accent">تصفح حسب الأقسام</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {categories.map((cat) => (
          <CategoryCard key={cat.id} category={cat} />
        ))}
      </div>
    </section>
  );
}

function CategoryCard({ category }) {
  return (
    <Link
      to={`/section/${category.id}`}
      className="group bg-secondary rounded-lg p-6 flex flex-col justify-between hover:shadow-lg transition-shadow"
    >
      <div className="flex items-center justify-between mb-4">
        <div className="text-3xl">
          {category.icon}
        </div>
        <div className="text-sm bg-accent text-white px-2 py-0.5 rounded-full">
          {category.count} مقال
        </div>
      </div>
      <h3 className="text-xl font-bold group-hover:text-accent transition-colors">
        {category.name}
      </h3>
    </Link>
  );
}

export default Categories;