import React from 'react';
import { Link } from 'react-router-dom';

/**
 * قسم البطل (Hero) في الصفحة الرئيسية. يعرض صورة تجريدية ورسالة ترحيبية.
 */
export default function HeroSection() {
  return (
    <section className="relative h-[60vh] flex items-center justify-center text-center overflow-hidden">
      {/* الخلفية */}
      <div className="absolute inset-0">
        {/* صورة مكانية؛ يمكن استبدالها بصور مولدة أو حقيقية */}
        <img
          src="/images/hero-placeholder.jpg"
          alt="خلفية هندسية إسلامية"
          className="w-full h-full object-cover opacity-60"
        />
        {/* طبقة تظليل لتقوية النص */}
        <div className="absolute inset-0 bg-primary opacity-70"></div>
      </div>
      {/* المحتوى */}
      <div className="relative z-10 p-4 max-w-2xl mx-auto">
        <h1 className="text-3xl md:text-5xl font-amiri mb-4 text-lightText">
          مرحبًا بكم في فرسان العقيدة
        </h1>
        <p className="text-md md:text-xl mb-6 text-lightText/90 leading-relaxed">
          منصة إسلامية باللغة العربية لنشر المقالات العقدية والفقهية والردود العلمية على الشبهات والمخالفات.
        </p>
        <Link
          to="/section/aqidah"
          className="inline-block bg-accent text-white px-6 py-2 rounded-md hover:bg-accent/90 transition-colors"
        >
          ابدأ القراءة
        </Link>
      </div>
    </section>
  );
}