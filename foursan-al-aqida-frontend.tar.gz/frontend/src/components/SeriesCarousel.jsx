import React from 'react';
import SeriesCard from './SeriesCard.jsx';

/**
 * قسم الكاروسيل لعرض السلاسل العلمية. يستخدم سلايدر أفقي بسيط.
 */
export default function SeriesCarousel({ series }) {
  if (!series || series.length === 0) return null;
  return (
    <section className="py-12 bg-primary dark:bg-primary border-t border-secondary/40">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-amiri mb-6 text-accent">السلاسل العلمية</h2>
        <div className="flex space-x-4 rtl:space-x-reverse overflow-x-auto hide-scrollbar">
          {series.map((item) => (
            <div key={item.id} className="min-w-[70%] md:min-w-[33%] flex-shrink-0">
              <SeriesCard series={item} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}