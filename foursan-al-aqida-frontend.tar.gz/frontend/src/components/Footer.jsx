import React from 'react';

/**
 * تذييل بسيط يعرض حقوق النشر وسنة الإنتاج.
 */
export default function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="bg-primary dark:bg-primary border-t border-secondary/40 py-6 text-center text-sm text-lightText/70">
      &copy; {year} فرسان العقيدة. جميع الحقوق محفوظة.
    </footer>
  );
}