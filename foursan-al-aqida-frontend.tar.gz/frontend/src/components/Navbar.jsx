import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import DarkModeToggle from './DarkModeToggle.jsx';
import { categories } from '../data/sampleData.js';

/**
 * شريط التنقل الرئيسي. يتضمّن شعار الموقع وروابط الأقسام وزر الوضع الليلي.
 */
export default function Navbar({ dark, setDark }) {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-primary dark:bg-primary border-b border-secondary/40">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* الشعار */}
        <Link
          to="/"
          className="font-amiri text-2xl text-accent hover:text-accent/80 whitespace-nowrap"
        >
          فرسان العقيدة
        </Link>
        {/* روابط سطح المكتب */}
        <nav className="hidden md:flex items-center space-x-6 rtl:space-x-reverse text-lightText">
          <Link to="/" className="hover:text-accent transition-colors">الرئيسية</Link>
          {/* قائمة الأقسام */}
          <div className="relative group">
            <button
              type="button"
              className="hover:text-accent transition-colors"
            >
              الأقسام
            </button>
            {/* القائمة المنسدلة */}
            <div className="absolute right-0 mt-2 w-40 bg-primary dark:bg-primary border border-secondary/40 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none group-hover:pointer-events-auto text-sm">
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  to={`/section/${cat.id}`}
                  className="block px-4 py-2 hover:bg-secondary/20"
                >
                  {cat.name}
                </Link>
              ))}
            </div>
          </div>
          <Link to="/tags" className="hover:text-accent transition-colors">الوسوم</Link>
          <Link to="/series" className="hover:text-accent transition-colors">السلاسل</Link>
          <Link to="/about" className="hover:text-accent transition-colors">حول الموقع</Link>
        </nav>
        {/* منطقة الأزرار */}
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          {/* حقل البحث */}
          <div className="hidden md:block relative">
            <input
              type="search"
              placeholder="ابحث..."
              className="w-40 bg-secondary/20 text-lightText placeholder-lightText/60 py-1 px-3 rounded-md focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>
          {/* زر تسجيل الدخول */}
          <Link
            to="/login"
            className="hidden md:inline-block bg-accent text-white px-4 py-1.5 rounded-md hover:bg-accent/90 transition-colors"
          >
            دخول
          </Link>
          {/* زر القائمة للهاتف */}
          <button
            type="button"
            className="md:hidden text-lightText text-xl"
            onClick={() => setMenuOpen((o) => !o)}
          >
            <i className={menuOpen ? 'fas fa-times' : 'fas fa-bars'}></i>
          </button>
          {/* زر الوضع الليلي */}
          <DarkModeToggle dark={dark} setDark={setDark} />
        </div>
      </div>
      {/* قائمة الهاتف المنسدلة */}
      {menuOpen && (
        <div className="md:hidden bg-primary dark:bg-primary border-t border-secondary/40 px-4 py-4 space-y-2 text-lightText">
          <Link to="/" onClick={() => setMenuOpen(false)} className="block hover:text-accent">الرئيسية</Link>
          {categories.map((cat) => (
            <Link
              key={cat.id}
              to={`/section/${cat.id}`}
              onClick={() => setMenuOpen(false)}
              className="block hover:text-accent"
            >
              {cat.name}
            </Link>
          ))}
          <Link to="/tags" onClick={() => setMenuOpen(false)} className="block hover:text-accent">الوسوم</Link>
          <Link to="/series" onClick={() => setMenuOpen(false)} className="block hover:text-accent">السلاسل</Link>
          <Link to="/about" onClick={() => setMenuOpen(false)} className="block hover:text-accent">حول الموقع</Link>
          <Link to="/login" onClick={() => setMenuOpen(false)} className="block hover:text-accent">دخول</Link>
        </div>
      )}
    </header>
  );
}