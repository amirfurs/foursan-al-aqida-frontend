import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

/**
 * صفحة تسجيل الدخول. يتم التحقق من صحة الحقول محليًا ثم الانتقال الوهمي إلى الملف الشخصي.
 */
export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError('يرجى ملء جميع الحقول');
      return;
    }
    // هنا يمكن إجراء طلب إلى واجهة برمجية للتحقق من بيانات الدخول
    setError('');
    // الانتقال إلى الملف الشخصي كتجربة
    navigate('/profile');
  };

  return (
    <div className="container mx-auto px-4 py-20 flex justify-center">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md bg-secondary/20 p-6 rounded-lg text-lightText"
      >
        <h2 className="text-2xl font-amiri mb-4 text-accent text-center">تسجيل الدخول</h2>
        {error && (
          <p className="mb-3 text-red-500 text-sm text-center">{error}</p>
        )}
        <div className="mb-4">
          <label className="block mb-1" htmlFor="email">
            البريد الإلكتروني
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 rounded bg-secondary/40 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="example@domain.com"
          />
        </div>
        <div className="mb-4">
          <label className="block mb-1" htmlFor="password">
            كلمة المرور
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 rounded bg-secondary/40 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="********"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-accent text-white py-3 rounded hover:bg-accent/90 transition-colors"
        >
          دخول
        </button>
        <p className="mt-4 text-center text-sm">
          لا تملك حسابًا؟{' '}
          <Link to="/register" className="text-accent hover:underline">
            أنشئ حسابًا جديدًا
          </Link>
        </p>
      </form>
    </div>
  );
}