import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { categories, articles } from '../data/sampleData.js';
import ArticleCard from '../components/ArticleCard.jsx';

/**
 * صفحة خاصة بكل قسم تعرض المقالات التابعة له.
 */
export default function SectionPage() {
  const { id } = useParams();
  const category = categories.find((c) => c.id === id);
  const filtered = articles.filter((a) => {
    return (category && a.category === category.name);
  });
  if (!category) {
    return (
      <div className="container mx-auto px-4 py-20 text-center text-lightText">
        <h2 className="text-2xl font-amiri mb-4">القسم غير موجود</h2>
        <Link to="/" className="text-accent hover:underline">العودة إلى الرئيسية</Link>
      </div>
    );
  }
  return (
    <div className="container mx-auto px-4 py-12 text-lightText">
      <h1 className="text-3xl font-amiri mb-6 text-accent">قسم {category.name}</h1>
      {filtered.length === 0 ? (
        <p>لا توجد مقالات متاحة في هذا القسم بعد.</p>
      ) : (
        <div className="grid md:grid-cols-3 gap-6">
          {filtered.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
}