import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';

/**
 * صفحة إنشاء حساب جديد. تتحقق من صحة الحقول وتعيد توجيه المستخدم بعد التسجيل الوهمي.
 */
export default function RegisterPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name || !email || !password) {
      setError('يرجى ملء جميع الحقول');
      return;
    }
    setError('');
    // هنا يمكن إرسال البيانات إلى واجهة برمجية لإنشاء المستخدم
    navigate('/login');
  };

  return (
    <div className="container mx-auto px-4 py-20 flex justify-center">
      <form
        onSubmit={handleSubmit}
        className="w-full max-w-md bg-secondary/20 p-6 rounded-lg text-lightText"
      >
        <h2 className="text-2xl font-amiri mb-4 text-accent text-center">إنشاء حساب</h2>
        {error && (
          <p className="mb-3 text-red-500 text-sm text-center">{error}</p>
        )}
        <div className="mb-4">
          <label className="block mb-1" htmlFor="name">
            الاسم الكامل
          </label>
          <input
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full p-3 rounded bg-secondary/40 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="أدخل اسمك"
          />
        </div>
        <div className="mb-4">
          <label className="block mb-1" htmlFor="email">
            البريد الإلكتروني
          </label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full p-3 rounded bg-secondary/40 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="example@domain.com"
          />
        </div>
        <div className="mb-4">
          <label className="block mb-1" htmlFor="password">
            كلمة المرور
          </label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="w-full p-3 rounded bg-secondary/40 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="********"
          />
        </div>
        <button
          type="submit"
          className="w-full bg-accent text-white py-3 rounded hover:bg-accent/90 transition-colors"
        >
          إنشاء حساب
        </button>
        <p className="mt-4 text-center text-sm">
          لديك حساب بالفعل؟{' '}
          <Link to="/login" className="text-accent hover:underline">
            تسجيل الدخول
          </Link>
        </p>
      </form>
    </div>
  );
}