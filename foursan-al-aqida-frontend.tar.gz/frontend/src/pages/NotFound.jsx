import React from 'react';
import { Link } from 'react-router-dom';

/**
 * صفحة لعرض رسالة عند زيارة مسار غير معروف.
 */
export default function NotFound() {
  return (
    <div className="container mx-auto px-4 py-24 text-center text-lightText">
      <h2 className="text-4xl font-amiri mb-4 text-accent">404</h2>
      <p className="mb-6">عذراً، الصفحة التي تبحث عنها غير موجودة.</p>
      <Link to="/" className="text-accent hover:underline">العودة إلى الصفحة الرئيسية</Link>
    </div>
  );
}