import React from 'react';
import HeroSection from '../components/HeroSection.jsx';
import LatestArticles from '../components/LatestArticles.jsx';
import CategoriesSection from '../components/CategoriesSection.jsx';
import TagCloud from '../components/TagCloud.jsx';
import SeriesCarousel from '../components/SeriesCarousel.jsx';
import { articles, categories, tags, series } from '../data/sampleData.js';

/**
 * الصفحة الرئيسية للموقع. تجمع بين عدة أقسام مثل البطل وأحدث المقالات والأقسام والوسوم والسلاسل.
 */
export default function Home() {
  return (
    <>
      <HeroSection />
      <LatestArticles articles={articles} />
      <CategoriesSection categories={categories} />
      <TagCloud tags={tags} />
      <SeriesCarousel series={series} />
    </>
  );
}