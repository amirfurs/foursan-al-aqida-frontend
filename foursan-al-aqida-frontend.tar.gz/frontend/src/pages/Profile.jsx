import React from 'react';
import { Link } from 'react-router-dom';

/**
 * صفحة الملف الشخصي. تعرض معلومات المستخدم وإمكانية تعديلها.
 */
export default function ProfilePage() {
  // في التطبيق الحقيقي ستُجلب بيانات المستخدم من الخادم بعد تسجيل الدخول
  const user = {
    name: 'مستخدم تجريبي',
    email: 'user@example.com',
    bio: 'هذا نص تجريبي لنبذة قصيرة عن المستخدم. يمكن تعديل هذه المعلومات من خلال لوحة التحكم.',
  };
  return (
    <div className="container mx-auto px-4 py-20 text-lightText">
      <div className="max-w-xl mx-auto bg-secondary/20 p-6 rounded-lg">
        <h2 className="text-2xl font-amiri mb-4 text-accent">الملف الشخصي</h2>
        <p className="mb-2">
          <span className="font-semibold">الاسم:</span> {user.name}
        </p>
        <p className="mb-2">
          <span className="font-semibold">البريد الإلكتروني:</span> {user.email}
        </p>
        <p className="mb-4">
          <span className="font-semibold">نبذة:</span> {user.bio}
        </p>
        <Link to="/" className="text-accent hover:underline">العودة إلى الرئيسية</Link>
      </div>
    </div>
  );
}