import React, { useState, useEffect, useRef } from 'react';
import { useParams, Link } from 'react-router-dom';
import { articles } from '../data/sampleData.js';

/**
 * صفحة عرض مقال مفصل. تتضمن شريط تقدم القراءة وتعليقات بسيطة.
 */
export default function ArticlePage() {
  const { id } = useParams();
  const article = articles.find((a) => a.id === id);
  const [comments, setComments] = useState([
    { id: 1, name: 'أحمد', text: 'مقال رائع جزاكم الله خيرًا.' },
    { id: 2, name: 'فاطمة', text: 'استفدت كثيرًا من المعلومات الواردة هنا.' },
  ]);
  const [commentText, setCommentText] = useState('');
  const contentRef = useRef(null);
  const progressRef = useRef(null);

  // حساب نسبة التمرير للبرنامج
  useEffect(() => {
    const handleScroll = () => {
      if (contentRef.current && progressRef.current) {
        const element = contentRef.current;
        const rect = element.getBoundingClientRect();
        const totalHeight = element.scrollHeight - rect.height;
        const scrollTop = window.scrollY - element.offsetTop;
        const percent = Math.min(Math.max(scrollTop / totalHeight, 0), 1);
        progressRef.current.style.width = `${percent * 100}%`;
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!article) {
    return (
      <div className="container mx-auto px-4 py-20 text-center text-lightText">
        <h2 className="text-2xl font-amiri mb-4">المقال غير موجود</h2>
        <Link to="/" className="text-accent hover:underline">العودة إلى الصفحة الرئيسية</Link>
      </div>
    );
  }

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (!commentText.trim()) return;
    setComments((prev) => [
      ...prev,
      { id: prev.length + 1, name: 'مستخدم', text: commentText.trim() },
    ]);
    setCommentText('');
  };

  return (
    <div className="container mx-auto px-4 py-8 text-lightText">
      {/* شريط تقدم القراءة */}
      <div className="fixed top-[4rem] left-0 right-0 h-1 bg-secondary/30 z-40">
        <div ref={progressRef} className="h-full bg-accent w-0"></div>
      </div>
      <article ref={contentRef} className="prose prose-invert max-w-3xl mx-auto">
        <h1 className="font-amiri text-3xl mb-4 text-accent">{article.title}</h1>
        <p className="text-sm text-lightText/60 mb-6">نشر بتاريخ {article.date}</p>
        {/* نص المقال */}
        <p className="mb-4 leading-loose">{article.content}</p>
        {/* المشاركة */}
        <div className="flex items-center space-x-4 rtl:space-x-reverse my-6">
          <span className="text-sm">مشاركة:</span>
          <a
            href={`https://twitter.com/share?url=${window.location.href}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent hover:underline"
          >
            <i className="fab fa-twitter"></i>
          </a>
          <a
            href={`https://www.facebook.com/sharer/sharer.php?u=${window.location.href}`}
            target="_blank"
            rel="noopener noreferrer"
            className="text-accent hover:underline"
          >
            <i className="fab fa-facebook"></i>
          </a>
        </div>
      </article>
      {/* قسم التعليقات */}
      <section className="max-w-3xl mx-auto mt-12">
        <h2 className="text-2xl font-amiri mb-4 text-accent">التعليقات ({comments.length})</h2>
        <ul className="space-y-4 mb-6">
          {comments.map((c) => (
            <li key={c.id} className="bg-secondary/20 p-4 rounded">
              <p className="font-semibold text-accent mb-1">{c.name}</p>
              <p className="text-sm text-lightText/90">{c.text}</p>
            </li>
          ))}
        </ul>
        <form onSubmit={handleCommentSubmit} className="space-y-3">
          <textarea
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            className="w-full h-24 p-3 rounded bg-secondary/20 text-lightText placeholder-lightText/60 focus:outline-none focus:ring-2 focus:ring-accent"
            placeholder="اكتب تعليقك هنا..."
          ></textarea>
          <button
            type="submit"
            className="bg-accent text-white px-4 py-2 rounded hover:bg-accent/90 transition-colors"
          >
            إضافة تعليق
          </button>
        </form>
      </section>
    </div>
  );
}